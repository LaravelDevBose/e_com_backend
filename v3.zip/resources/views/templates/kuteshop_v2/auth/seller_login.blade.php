@extends('templates.kuteshop_v2.layouts.frontend.master')

@section('Title','Seller Authentication')

@section('PageCss')

@endsection

@section('Content')
    <seller-auth-page></seller-auth-page>
@endsection

@section('PageJs')

@endsection
