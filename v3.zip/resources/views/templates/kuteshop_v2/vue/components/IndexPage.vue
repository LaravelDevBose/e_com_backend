<template>

</template>

<script>
    export default {
        name: "IndexPage"
    }
</script>

<style scoped>

</style>
