@extends('templates.crocus_v2.layouts.frontend.master')

@section('Title', 'About Us')

@section('PageCss')

@endsection

@section('Content')
<about-us></about-us>
@endsection

@section('PageJs')

@endsection
