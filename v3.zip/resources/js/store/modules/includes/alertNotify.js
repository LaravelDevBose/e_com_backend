

//declare State
const state={
    show:false,
};

//declare Getters
const getters = {
    showAlert:(state)=>state.show
};

const actions={

};

const mutations ={

};

export default {
    state,
    getters,
    actions,
    mutations,
}
