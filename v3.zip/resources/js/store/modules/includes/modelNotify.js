

//declare State
const state={

};

//declare Getters
const getters = {

};

const actions={

};

const mutations ={

};

export default {
    state,
    getters,
    actions,
    mutations,
}
