<template>
    <!-- Content area -->
    <div class="content" >
        <!-- Dashboard content -->
        <div class="row">
            <div class="col-lg-12">
                <!-- Latest posts -->
                <div class="panel panel-flat bounceInRight" >
                    <div class="panel-body">
                        <h1 class="text text-blue  text-center text-bold">
                            <span> Well come to {{ panel }}
                            </span>
                        </h1>
                    </div>
                </div>
                <!-- /latest posts -->

            </div>

        </div>
        <!-- /dashboard content -->
    </div>
    <!-- /content area -->
</template>

<script>
    export default {
        name: "Dashboard",
        props:['panel']
    }
</script>

<style scoped>

</style>
