<template>

</template>

<script>
    export default {
        name: "Campaign",

    }
</script>

<style scoped>

</style>
