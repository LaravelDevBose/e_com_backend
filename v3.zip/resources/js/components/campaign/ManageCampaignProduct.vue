<template>
    
</template>

<script>
    export default {
        name: "ManageCampaignProduct"
    }
</script>

<style scoped>

</style>