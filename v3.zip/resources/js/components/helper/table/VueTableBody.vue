<template>
    
</template>

<script>
    export default {
        name: "VueTableBody"
    }
</script>

<style scoped>

</style>