<template>
    <label class="radio-inline">
        <input type="radio" name="radio-inline-left" class="styled control-primary" checked="checked">
        Selected styled
    </label>
</template>

<script>
    export default {
        name: "VueRadio"
    }
</script>

<style scoped>

</style>
