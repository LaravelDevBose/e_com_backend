<template>
    <div>
        <textarea cols="18" rows="3" class="wysihtml5 wysihtml5-min " placeholder="Enter text ..."></textarea>
    </div>
</template>

<script>
    export default {
        name: "WysiHtml"
    }
</script>

<style scoped>

</style>
