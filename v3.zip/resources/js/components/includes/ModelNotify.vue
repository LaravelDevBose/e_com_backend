<template>
    
</template>

<script>
    export default {
        name: "PopUpNotifyMsg"
    }
</script>

<style scoped>

</style>
