<template>
    <div class="panel panel-body">
        <div class="row">
            <div class="col-xs-12 form-inline" style="margin:1em;">
                <div class="form-group">
                    <input type="text" id="filter" class="form-control" v-model="filter" placeholder="Filter">
                </div>
            </div>
            <div id="table" class="col-xs-12">
                <div class="table-responsive">
                    <datatable class="table table-bordered table-striped" :columns="columns" :data="order_items" :filter-by="filter"></datatable>
                </div>
            </div>
            <div class="col-xs-12 form-inline">
                <datatable-pager v-model="page" type="abbreviated" :per-page="per_page"></datatable-pager>
            </div>
        </div>
    </div>
</template>

<script>

    import {mapGetters, mapActions} from 'vuex';

    Vue.component('thumb-image', {
        template: `<img :src="row.product.thumb_image.image_path" :alt="row.product_name"  style="width:40px; height:40px">`,
        props: ['row'],
    });

    Vue.component('status-badge', {
        template: `<div class="btn-group">
                        <span  class="label  dropdown-toggle"
                            :class="{'bg-info':row.item_status == 1, 'bg-danger':row.item_status == 2, 'bg-warning':row.item_status == 3, 'bg-primary':row.item_status == 4, 'bg-indigo-400':row.item_status == 5, 'bg-teal':row.item_status == 6 }"
                            data-toggle="dropdown" aria-expanded="false">
                            {{ row.item_status_label }}
                        </span>
                    </div>`,
        props: ['row']
    });
    Vue.component('product-info', {
        template: ` <a href="#" @click.prevent="showProduct(row.product.product_slug)" class="text-semibold">{{ row.product_name }}</a>
            <div class="text-muted text-size-small">
                <span class="status-mark bg-grey position-left"></span>
                    {{ row.product.product_sku }}
            </div>
        `,
        props: ['row'],
        methods:{
            showProduct(product_slug){
                location.href=`/admin/product/${product_slug}`;
            }
        }
    });

    export default {
        name: "ShopOrderListTable",
        props:['reqData'],
        data(){
            return {
                page: 1,
                per_page:10,
                order_items:'',
                filter: '',
                rows:'',
                columns: [
                    { label: 'Image', component: 'thumb-image', align: 'center', sortable: false },
                    { label: 'Product Name', component: 'product-info' },
                    { label: 'Order No', field: 'order.order_no'},
                    { label: 'Order Date', field: 'order.order_date', filterable: true, sortable:true },
                    { label: 'Buyer', field: 'buyer.user.full_name' , filterable: true, sortable:true },
                    { label: 'Brand', field: 'brand', filterable: true, sortable:true },
                    { label: 'Price', field: 'price', align: 'right',},
                    { label: 'Quantity', field: 'qty', align: 'right',  },
                    { label: 'Total', field: 'total_price', align: 'right', sortable: true },
                    { label: 'Status', field: 'item_status', component: 'status-badge', align: 'center', sortable: true }
                ],

            }
        },
        created(){

        },
        mounted(){
            this.getShopOrderItemList(this.reqData).then(response=>{
                if(typeof response.code !== "undefined" && response.code === 200){
                    this.order_items = this.orderItemList;
                    this.per_page= this.reqData.paginate;
                }else{
                    alert(response.message);
                }
            })
        },
        methods:{
            ...mapActions([
                'getShopOrderItemList',
            ]),

            sortBy(key) {

                this.sortKey = key;
                this.sortOrders[key] = this.sortOrders[key] * -1;
                this.tableData.column = this.getIndex(this.columns, 'name', key);
                this.tableData.dir = this.sortOrders[key] === 1 ? 'asc' : 'desc';
                console.log(this.tableData);
                this.getProductsData();
            },
            getIndex(array, key, value) {
                return array.findIndex(i => i[key] == value)
            },
        },
        computed:{
            ...mapGetters([
                'orderItemList'
            ])
        }
    }
</script>

<style scoped>

</style>
